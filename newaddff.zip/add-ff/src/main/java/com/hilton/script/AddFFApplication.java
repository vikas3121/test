package com.hilton.script;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.hilton.script.addff.service.ExcelService;
import com.hilton.script.addff.service.RestService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

@SpringBootApplication
public class AddFFApplication implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(AddFFApplication.class);

    @Autowired
    private ExcelService excelService;

    @Autowired
    private RestService restService;

    public static void main(String[] args) {
        SpringApplication.run(AddFFApplication.class, args);
    }

    @Override
    public void run(String... args) {
        if (args.length > 0) {
            String filePath = args[0];
            logger.info("Starting processing of file: {}", filePath);
            try {
                List<String[]> data = excelService.readExcelFile(filePath);
                for (String[] row : data) {
                    restService.callRestService(row);
                }
                logger.info("File processed successfully");
            } catch (Exception e) {
                logger.error("Failed to process file", e);
            }
        } else {
            logger.error("No file path provided");
        }
    }
}

