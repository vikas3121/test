package com.hilton.script.addff;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AddFfApplication {

	public static void main(String[] args) {
		SpringApplication.run(AddFfApplication.class, args);
	}

}
