package com.hilton.script.addff.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class RestService { 

    @Autowired
    private RestTemplate restTemplate;

    public void callRestService(String[] data) {
        // Create request body using data
        // Assuming data has necessary information
        String url = "http://example.com/api/resource"; // Replace with actual URL
        ResponseEntity<String> response = restTemplate.postForEntity(url, data, String.class);
        System.out.println("Response: " + response.getBody());
    }
}
