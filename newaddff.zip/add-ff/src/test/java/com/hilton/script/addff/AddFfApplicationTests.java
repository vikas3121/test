package com.hilton.script.addff;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AddFfApplicationTests {

	@Test
	void contextLoads() {
	}

}
